package jp.ac.jec.cm0123.svlinksample;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class EntryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        finish();
    }
}
