package jp.ac.jec.cm0123.svlinksample;

public class GoodsDetail {
    private int id;
    private String name;
    private int price;
    private int costPrice;
    private int stock;
    private String category;
    private String maker;
    private String makerUrl;
    private String image;
    private String detail;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getPrice() { return price; }
    public void setPrice(int price) { this.price = price; }
    public int getCostPrice() { return costPrice; }
    public void setCostPrice(int costPrice) { this.costPrice = costPrice; }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getMaker() { return maker; }
    public void setMaker(String maker) { this.maker = maker; }
    public String getMakerUrl() { return makerUrl; }
    public void setMakerUrl(String makerUrl) { this.makerUrl = makerUrl; }
    public String getImage() { return image; }
    public void setImage(String image) { this.image = image; }
    public String getDetail() { return detail; }
    public void setDetail(String detail) { this.detail = detail; }
}
