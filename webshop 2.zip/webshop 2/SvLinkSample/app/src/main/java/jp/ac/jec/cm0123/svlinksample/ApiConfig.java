package jp.ac.jec.cm0123.svlinksample;

public class ApiConfig {
    public static final String BASE_URL = "http://24cm0123.main.jp/mobileApi/";
    public static final String IMAGE_BASE_URL = "http://24cm0123.main.jp/goodsImg/";
}
