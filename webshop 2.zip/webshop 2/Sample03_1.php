<html>
    <head>
        <title>Sample03_1.php</title>
    </head>
    <body>
        <h2>メーカー名検索</h2>
        <form action=" ./Sample03_2.php" method="POST">
            <input type="text" name="searchName">
            <input type="submit" value="検索">
        </form>
    </body>
</html>